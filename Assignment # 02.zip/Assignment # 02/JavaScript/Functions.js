//Functions

// Function declaration
function calcAge1(birthYeah) {
    return 2037 - birthYeah;
}
const age1 = calcAge1(1991);

// Function expression
const calcAge2 = function (birthYeah) {
    return 2037 - birthYeah;
}
const age2 = calcAge2(1991);

console.log(age1, age2);

// Function String
function describeCountry(country, population, capitalCity) {
    const countryDetail = `${country} has ${population} people and its capital city is ${capitalCity}`;
    return countryDetail;
}

console.log(describeCountry('Pakistan', '8 Million', 'Islamabad'));
console.log(describeCountry('Australia', '3 Million', 'Sydney'));
console.log(describeCountry('Germany', '10 Million', 'Muncih'));
