// Strings and Template Literals
const firstName = 'Zain';
const job = 'Developer';
const birthYear = 1999;
const year = 2022;

// Through Normal String
const myString = "I'm " + firstName + ', a ' + (year - birthYear) + ' year old ' + job + '!';
console.log(myString);

// Through Template Literals
const newString = `I'm ${firstName}, a ${year - birthYear} year old ${job}!`;
console.log(newString);

console.log(`Just a regular string...`);

console.log('String with \n\
multiple \n\
lines');

console.log(`String
multiple
lines`);