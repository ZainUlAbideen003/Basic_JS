// In JavaScript we have 7 types of data types.

// 1. Null
// 2. Number
// 3. String
// 4. Symbol
// 5. Boolean
// 6. Bigint
// 7. Undefined

let a = null;
let b = 234;
let c = "Zain Ahmad";
let d = Symbol("I'm a symbol");
let e = true;
let f = BigInt(456);
let g = undefined;

console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(e);
console.log(f);
console.log(g);

console.log(typeof a);
console.log(typeof b);
console.log(typeof c);
console.log(typeof d);
console.log(typeof e);
console.log(typeof f);
console.log(typeof g);


