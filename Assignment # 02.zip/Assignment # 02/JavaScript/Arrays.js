//Arrays

const Array1 = ["Zain", "Rashid", "Salman"];
console.log(Array1)

Array1.push("Nabeel"); //Add in the end
console.log(Array1)

Array1.unshift("Umair"); //Add in the first
console.log(Array1)

Array1.pop(); //Remove in the end element
console.log(Array1)

Array1.shift(); //Remove in the first element
console.log(Array1)

console.log(Array1.indexOf("Zain")); //Helped to find index or element in array

console.log(Array1.includes("Rashid")); //Its just True when element exist in array otherwise give false

