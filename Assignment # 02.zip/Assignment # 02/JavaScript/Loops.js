// Iteration: The for Loop

// for loop keeps running while condition is TRUE
for (let i = 1; i <= 10; i++) {
    console.log(`2 * ${i} = ${2 * i}`);
}

//While loop
let i = 1;
while (i <= 10) {
    console.log(`3 * ${i} = ${3 * i}`);
    i++;
}